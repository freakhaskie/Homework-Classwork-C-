#ifndef TYPES_H_INCLUDED
#define TYPES_H_INCLUDED

using namespace std;

#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include "Helper.h"

#endif // TYPES_H_INCLUDED
